# CHIP-8 Emulator (2019)

A simple emulator for the CHIP-8.

[Here is a blog post about it.](https://austinmorlan.com/posts/chip8_emulator/)

![Demo](https://austinmorlan.com/posts/chip8_emulator/media/demo.gif)

